#!/usr/bin/env python3
"""
CyberOS HUD — Real Metrics Companion
====================================
Serves your *actual* system stats as JSON on http://localhost:8377/metrics
so the Wallpaper Engine wallpaper can display real CPU / RAM / disk / network
data instead of the built-in simulation.

This is OPTIONAL. If you never run it, the wallpaper falls back to realistic
simulated metrics. Run it any time and the wallpaper auto-detects it within
~1 second and switches to live data; close it and it falls back again.

Requirements:
    pip install psutil

Run:
    python metrics_server.py
    (leave the window open; minimize it. Or set it to auto-start — see README.)

Stop:
    Close the window / Ctrl+C.

Security note: it binds to 127.0.0.1 only (loopback), so it is not reachable
from other machines on your network. It serves read-only stats. The one thing it
writes is a backup copy of the wallpaper's dragged panel layout, and only a
wallpaper on this PC can write or read that.

Performance: the once-per-second sample does NOT spawn any subprocess. GPU stats
come from the NVIDIA NVML library (loaded once via ctypes), disk stats from
psutil, and on Windows the whole process table from one system call. The few
things that do shell out — monitor list, GPU/CPU model, the logical→physical
drive map — run once at startup; Tailscale runs on a slow 5 s thread. This
keeps steady-state CPU to a few percent of one core. (nvidia-smi / a startup
PowerShell remain as fallbacks, so nothing is lost if NVML or WMI is unavailable.)
"""

import ctypes
import json
import os
import platform
import re
import subprocess
import sys
import time
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# When launched with pythonw.exe (no console) — which is how it auto-starts at
# login — sys.stdout/stderr are None, so any print() raises AttributeError and
# kills the process before it ever serves. Route them to the null device so the
# server runs truly headless. Harmless when a real console is attached.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

try:
    import psutil
except ImportError:
    raise SystemExit(
        "\n[!] psutil is not installed.\n"
        "    Install it with:  pip install psutil\n"
    )

PORT = 8377
HOST = "127.0.0.1"

NCORES = psutil.cpu_count(logical=True) or 1
# boot_time never changes while we run — read it once instead of every sample.
BOOT_TIME = psutil.boot_time()
# sensors_temperatures exists only on Linux/macOS/FreeBSD; checking once avoids
# raising (and swallowing) an AttributeError on Windows every single second.
_HAS_TEMP = hasattr(psutil, "sensors_temperatures")
# Windows reports the idle task as a process with huge CPU; never show it.
IDLE_NAMES = {"system idle process", "idle"}
# Hide the subprocess console window on Windows; harmless flag elsewhere.
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


# Reads each attached display's true current mode (dmPelsWidth/Height) via
# EnumDisplaySettings — DPI/scaling-independent, so a 4K next to a 1440p
# reports "3840x2160, 2560x1440" correctly (AllScreens.Bounds does not).
_PS_MONITORS = r'''
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class DM {
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct DEVMODE {
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string dmDeviceName;
    public ushort dmSpecVersion; public ushort dmDriverVersion; public ushort dmSize;
    public ushort dmDriverExtra; public uint dmFields;
    public int dmPositionX; public int dmPositionY;
    public uint dmDisplayOrientation; public uint dmDisplayFixedOutput;
    public short dmColor; public short dmDuplex; public short dmYResolution;
    public short dmTTOption; public short dmCollate;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string dmFormName;
    public ushort dmLogPixels; public uint dmBitsPerPel;
    public uint dmPelsWidth; public uint dmPelsHeight;
    public uint dmDisplayFlags; public uint dmDisplayFrequency;
    public uint dmICMMethod; public uint dmICMIntent; public uint dmMediaType;
    public uint dmDitherType; public uint dmReserved1; public uint dmReserved2;
    public uint dmPanningWidth; public uint dmPanningHeight;
  }
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct DISPLAY_DEVICE {
    public int cb;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string DeviceName;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=128)] public string DeviceString;
    public int StateFlags;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=128)] public string DeviceID;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=128)] public string DeviceKey;
  }
  [DllImport("user32.dll", CharSet=CharSet.Unicode)]
  public static extern bool EnumDisplayDevices(string dev, uint n, ref DISPLAY_DEVICE info, uint flags);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)]
  public static extern bool EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);
}
"@
$i = 0
while ($true) {
  $d = New-Object DM+DISPLAY_DEVICE
  $d.cb = [Runtime.InteropServices.Marshal]::SizeOf($d)
  if (-not [DM]::EnumDisplayDevices([NullString]::Value, $i, [ref]$d, 0)) { break }
  $i++
  if (($d.StateFlags -band 1) -eq 0) { continue }   # not attached to desktop
  $dm = New-Object DM+DEVMODE
  $dm.dmSize = [uint16][Runtime.InteropServices.Marshal]::SizeOf($dm)
  if ([DM]::EnumDisplaySettings($d.DeviceName, -1, [ref]$dm)) {
    # prefix 0 = primary display (StateFlags bit 0x4), 1 = secondary, so the
    # caller can sort the primary monitor to the front. Then resolution, refresh
    # Hz, and the monitor's top-left corner in virtual-desktop coordinates —
    # the wallpaper needs those to lay a spanned HUD out per monitor.
    $p = if (($d.StateFlags -band 4) -ne 0) { "0" } else { "1" }
    "$p $($dm.dmPelsWidth)x$($dm.dmPelsHeight) $($dm.dmDisplayFrequency) $($dm.dmPositionX) $($dm.dmPositionY)"
  }
}
'''


def _monitors():
    """Each attached monitor, primary first, as
    {'res','hz','w','h','x','y','primary'} — e.g.
    [{'res':'3840x2160','hz':120,'w':3840,'h':2160,'x':0,'y':0,'primary':True}, ...].

    x/y are the monitor's top-left corner in Windows virtual-desktop coordinates
    and may be negative for a display to the left of the primary. A wallpaper
    spanned across several monitors gets one viewport covering the bounding box
    of all of them, so this is what lets it work out where the seams are."""
    if sys.platform != "win32":
        return []
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", _PS_MONITORS],
            text=True, timeout=20, creationflags=NO_WINDOW)
        rows = []
        for ln in out.splitlines():
            parts = ln.strip().split()
            if len(parts) >= 2 and "x" in parts[1] and parts[1][0].isdigit():
                pri = parts[0]
                mon = {"res": parts[1], "hz": None}
                if len(parts) >= 3 and parts[2].isdigit():
                    mon["hz"] = int(parts[2])
                try:
                    w, h = parts[1].split("x")
                    mon["w"], mon["h"] = int(w), int(h)
                except Exception:
                    pass
                if len(parts) >= 5:
                    try:
                        mon["x"], mon["y"] = int(parts[3]), int(parts[4])
                    except ValueError:
                        pass
                mon["primary"] = (pri == "0")
                rows.append((pri, mon))
        rows.sort(key=lambda r: r[0])      # "0" (primary) sorts ahead of "1"
        return [m for _, m in rows] or []
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Fullscreen app in front: the wallpaper's cue for game mode (a still scene with
# live stats). Wallpaper Engine can only pause or keep running when a game goes
# fullscreen, and paused freezes the stats too, so with WE left running the
# wallpaper asks us instead. Answered per request: it is a handful of user32
# calls, and a cached answer would add up to a second of lag on top of the
# wallpaper's own debounce.
# ---------------------------------------------------------------------------
if sys.platform == "win32":
    from ctypes import wintypes

    class _MonInfo(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]

    # Our own handle to user32, so these prototypes never leak into the shared
    # ctypes.windll one the rest of the file uses.
    _u32 = ctypes.WinDLL("user32")
    _u32.GetForegroundWindow.restype = wintypes.HWND
    _u32.IsIconic.argtypes = [wintypes.HWND]
    _u32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _u32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    _u32.GetWindowLongW.restype = ctypes.c_long
    _u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    _u32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    _u32.MonitorFromWindow.restype = wintypes.HMONITOR
    _u32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, ctypes.POINTER(_MonInfo)]
    _HAS_DPI_CTX = hasattr(_u32, "SetThreadDpiAwarenessContext")   # Windows 10 1607+
    if _HAS_DPI_CTX:
        _u32.SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        _u32.SetThreadDpiAwarenessContext.restype = ctypes.c_void_p

# Shell surfaces that cover a whole monitor without being an app: the desktop
# itself, the taskbars, Start / search, and Alt+Tab / Task View.
_SHELL_CLASSES = {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd",
                  "Windows.UI.Core.CoreWindow", "XamlExplorerHostIslandWindow",
                  "MultitaskingViewFrame", "TaskSwitcherWnd", "ForegroundStaging"}
_WS_CAPTION = 0x00C00000
_DPI_PER_MONITOR_V2 = -4
_MONITOR_DEFAULTTONEAREST = 2


def _fills_monitor(hwnd):
    """True when hwnd covers every pixel of the monitor it is on and has no
    title bar: a game in exclusive or borderless fullscreen, or a video or
    browser gone fullscreen. A maximized window keeps its caption, and on an
    auto-hidden taskbar it does cover the monitor, so the caption is the test
    that tells the two apart."""
    prev = None
    if _HAS_DPI_CTX:
        # Physical pixels, whatever this process's DPI mode, so a game on a
        # scaled 4K panel is measured against the panel's real size.
        prev = _u32.SetThreadDpiAwarenessContext(ctypes.c_void_p(_DPI_PER_MONITOR_V2))
    try:
        if not hwnd or _u32.IsIconic(hwnd):
            return False
        cls = ctypes.create_unicode_buffer(128)
        _u32.GetClassNameW(hwnd, cls, 128)
        if cls.value in _SHELL_CLASSES:
            return False
        if (_u32.GetWindowLongW(hwnd, -16) & _WS_CAPTION) == _WS_CAPTION:
            return False
        r = wintypes.RECT()
        if not _u32.GetWindowRect(hwnd, ctypes.byref(r)):
            return False
        mon = _u32.MonitorFromWindow(hwnd, _MONITOR_DEFAULTTONEAREST)
        mi = _MonInfo()
        mi.cbSize = ctypes.sizeof(_MonInfo)
        if not mon or not _u32.GetMonitorInfoW(mon, ctypes.byref(mi)):
            return False
        m = mi.rcMonitor
        return (r.left <= m.left and r.top <= m.top
                and r.right >= m.right and r.bottom >= m.bottom)
    except Exception:
        return False
    finally:
        if prev:
            _u32.SetThreadDpiAwarenessContext(ctypes.c_void_p(prev))


def _fullscreen_app():
    """Whether the foreground window is a fullscreen app. None off Windows,
    where the field is left out of the payload entirely."""
    if sys.platform != "win32":
        return None
    try:
        return _fills_monitor(_u32.GetForegroundWindow())
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Drives: usage comes from psutil every second (no subprocess). Volume labels
# and the logical→physical-disk mapping (needed to attribute live read/write
# throughput to a drive letter) almost never change, so we resolve them ONCE
# at startup with a single WMI/PowerShell call and cache the result.
# ---------------------------------------------------------------------------
_PS_DRIVE_MAP = r'''
$map = @{}
Get-CimInstance Win32_LogicalDiskToPartition -ErrorAction SilentlyContinue | ForEach-Object {
  $log = $_.Dependent.DeviceID
  if ($_.Antecedent.DeviceID -match 'Disk #(\d+)') {
    if (-not $map.ContainsKey($log)) { $map[$log] = @() }
    $map[$log] += "PhysicalDrive$($matches[1])"
  }
}
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue | ForEach-Object {
  $p = if ($map.ContainsKey($_.DeviceID)) { (($map[$_.DeviceID] | Select-Object -Unique) -join ',') } else { '' }
  "$($_.DeviceID)|$($_.VolumeName)|$p"
}
'''


def _drive_static():
    """One-time map: 'C:' -> {'label': 'OS', 'phys': ['PhysicalDrive0']}.
    'phys' keys match psutil.disk_io_counters(perdisk=True) on Windows."""
    if sys.platform != "win32":
        return {}
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", _PS_DRIVE_MAP],
            text=True, timeout=15, creationflags=NO_WINDOW)
    except Exception:
        return {}
    m = {}
    for ln in out.splitlines():
        parts = ln.strip().split("|")
        if len(parts) == 3 and parts[0].endswith(":"):
            m[parts[0]] = {"label": parts[1],
                           "phys": [x for x in parts[2].split(",") if x]}
    return m


DRIVE_STATIC = _drive_static()


# ---------------------------------------------------------------------------
# Tailnet: peers from the local Tailscale CLI (status --json).
# ---------------------------------------------------------------------------
def _tailscale_exe():
    for cand in ("tailscale",
                 r"C:\Program Files\Tailscale\tailscale.exe",
                 r"C:\Program Files (x86)\Tailscale\tailscale.exe"):
        try:
            subprocess.check_output([cand, "version"], timeout=4,
                                    creationflags=NO_WINDOW, text=True)
            return cand
        except Exception:
            continue
    return None


TAILSCALE = _tailscale_exe()


def _tailnet():
    """Tailnet devices: self first, then peers (online before offline)."""
    if not TAILSCALE:
        return None
    try:
        out = subprocess.check_output([TAILSCALE, "status", "--json"],
                                      timeout=6, creationflags=NO_WINDOW, text=True)
        data = json.loads(out)
    except Exception:
        return None

    def node(n, is_self=False):
        return {
            "name": n.get("HostName") or "?",
            "os": n.get("OS") or "",
            "online": bool(n.get("Online")),
            "self": is_self,
            "rx": int(n.get("RxBytes") or 0),
            "tx": int(n.get("TxBytes") or 0),
            "last_seen": n.get("LastSeen") or "",
        }

    rows = []
    if data.get("Self"):
        rows.append(node(data["Self"], True))
    for peer in (data.get("Peer") or {}).values():
        rows.append(node(peer))
    # self first, then online, then offline; alphabetical within each group
    rows.sort(key=lambda r: (not r["self"], not r["online"], r["name"].lower()))
    return rows


# ---------------------------------------------------------------------------
# CPU clock: current core frequency in MHz. On Windows psutil.cpu_freq()
# reports a near-constant value (the base clock), so we compute it the way
# Task Manager does: the documented PDH counter "% Processor Performance"
# (percent of nominal frequency; exceeds 100 when boosting) times the base
# MHz. PDH is loaded once via ctypes; each 1 Hz sample is two cheap C calls.
# Falls back to psutil.cpu_freq() (accurate on Linux/macOS).
# ---------------------------------------------------------------------------
class _PdhValue(ctypes.Structure):
    # PDH_FMT_COUNTERVALUE with the union collapsed to its double member
    # (ctypes 8-aligns the double, matching the C struct layout).
    _fields_ = [("CStatus", ctypes.c_ulong), ("doubleValue", ctypes.c_double)]


class _CpuClock:
    def __init__(self):
        self.base = None          # nominal (base) MHz
        self.hi = None            # highest MHz seen (Windows has no documented
                                  # boost-ceiling API; base * %Performance exceeds
                                  # base whenever boosting, so report a high-water
                                  # mark that converges on the true boost clock)
        self.ok = False           # PDH counter usable
        try:
            f = psutil.cpu_freq()
            if f:
                self.base = float(f.max or f.current or 0) or None
        except Exception:
            pass
        if sys.platform != "win32":
            return
        if not self.base:
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                     r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
                self.base = float(winreg.QueryValueEx(key, "~MHz")[0])
            except Exception:
                return
        try:
            pdh = ctypes.WinDLL("pdh.dll")
            self._q = ctypes.c_void_p()
            if pdh.PdhOpenQueryW(None, 0, ctypes.byref(self._q)) != 0:
                return
            self._c = ctypes.c_void_p()
            path = r"\Processor Information(_Total)\% Processor Performance"
            if pdh.PdhAddEnglishCounterW(self._q, path, 0, ctypes.byref(self._c)) != 0:
                return
            pdh.PdhCollectQueryData(self._q)  # prime: rate counters need two samples
            self._pdh = pdh
            self.ok = True
        except Exception:
            pass

    def _seen(self, mhz):
        # max = high-water mark, never below base: the wallpaper scales its
        # clock bar against this, so it must stay >= the current reading.
        if self.hi is None or mhz > self.hi:
            self.hi = mhz
        return mhz, round(max(self.hi, self.base or 0)) or None

    def query(self):
        """Return (current_mhz, max_mhz); either may be None."""
        if self.ok:
            try:
                if self._pdh.PdhCollectQueryData(self._q) == 0:
                    v = _PdhValue()
                    # 0x200 = PDH_FMT_DOUBLE
                    if self._pdh.PdhGetFormattedCounterValue(
                            self._c, 0x200, None, ctypes.byref(v)) == 0:
                        return self._seen(round(self.base * v.doubleValue / 100.0))
            except Exception:
                self.ok = False
        try:
            f = psutil.cpu_freq()
            if f and f.current:
                return self._seen(round(f.current))
        except Exception:
            pass
        return None, round(self.base) if self.base else None


CPU_CLOCK = _CpuClock()


# ---------------------------------------------------------------------------
# GPU: live NVIDIA stats via the driver's NVML library, loaded once through
# ctypes. query() is a few cheap C calls — no per-second subprocess. Falls back
# to nvidia-smi (then to the wallpaper's simulated GPU) if NVML is unavailable.
# ---------------------------------------------------------------------------
class _NvUtil(ctypes.Structure):
    _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]


class _NvMem(ctypes.Structure):
    _fields_ = [("total", ctypes.c_ulonglong),
                ("free", ctypes.c_ulonglong),
                ("used", ctypes.c_ulonglong)]


class _NVML:
    def __init__(self):
        self.ok = False
        self.lib = None
        self.h = None
        try:
            lib = (ctypes.WinDLL("nvml.dll") if sys.platform == "win32"
                   else ctypes.CDLL("libnvidia-ml.so.1"))
        except Exception:
            return
        init = getattr(lib, "nvmlInit_v2", None) or getattr(lib, "nvmlInit", None)
        geth = (getattr(lib, "nvmlDeviceGetHandleByIndex_v2", None)
                or getattr(lib, "nvmlDeviceGetHandleByIndex", None))
        if not init or not geth:
            return
        try:
            if init() != 0:
                return
            geth.argtypes = [ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p)]
            h = ctypes.c_void_p()
            if geth(0, ctypes.byref(h)) != 0:
                return
            lib.nvmlDeviceGetUtilizationRates.argtypes = [ctypes.c_void_p, ctypes.POINTER(_NvUtil)]
            lib.nvmlDeviceGetMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(_NvMem)]
            lib.nvmlDeviceGetTemperature.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)]
        except Exception:
            return
        # Clocks (type 0 = NVML_CLOCK_GRAPHICS, 2 = NVML_CLOCK_MEM). Guarded
        # separately so a driver without these entry points still serves
        # util/temp/VRAM. The max clocks never change; read them once.
        self.clock_max = None
        self.mem_clock_max = None
        self._has_clock = False
        try:
            lib.nvmlDeviceGetClockInfo.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)]
            lib.nvmlDeviceGetMaxClockInfo.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)]
            self._has_clock = True
            c = ctypes.c_uint()
            if lib.nvmlDeviceGetMaxClockInfo(h, 0, ctypes.byref(c)) == 0:
                self.clock_max = float(c.value)
            if lib.nvmlDeviceGetMaxClockInfo(h, 2, ctypes.byref(c)) == 0:
                self.mem_clock_max = float(c.value)
        except Exception:
            pass
        self.lib = lib
        self.h = h
        self.ok = True

    def query(self):
        if not self.ok:
            return None
        try:
            u = _NvUtil()
            if self.lib.nvmlDeviceGetUtilizationRates(self.h, ctypes.byref(u)) != 0:
                return None
            m = _NvMem()
            if self.lib.nvmlDeviceGetMemoryInfo(self.h, ctypes.byref(m)) != 0:
                return None
            temp = None
            t = ctypes.c_uint()
            if self.lib.nvmlDeviceGetTemperature(self.h, 0, ctypes.byref(t)) == 0:
                temp = float(t.value)
            clock = mem_clock = None
            if self._has_clock:
                c = ctypes.c_uint()
                if self.lib.nvmlDeviceGetClockInfo(self.h, 0, ctypes.byref(c)) == 0:
                    clock = float(c.value)
                if self.lib.nvmlDeviceGetClockInfo(self.h, 2, ctypes.byref(c)) == 0:
                    mem_clock = float(c.value)
            return {"util": float(u.gpu), "temp": temp,
                    "clock": clock, "clock_max": self.clock_max,
                    "mem_clock": mem_clock, "mem_clock_max": self.mem_clock_max,
                    "vram_used": round(m.used / (1024 * 1024), 1),
                    "vram_total": round(m.total / (1024 * 1024), 1)}
        except Exception:
            return None


def _gpu_query():
    """Live NVIDIA GPU stats via nvidia-smi (fallback path used only when NVML
    isn't available). Returns None if no NVIDIA GPU / driver. AMD and Intel
    aren't covered; they fall back to the wallpaper's simulated GPU rows."""
    try:
        out = subprocess.check_output(
            ["nvidia-smi",
             "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,"
             "clocks.gr,clocks.max.gr,clocks.mem,clocks.max.mem",
             "--format=csv,noheader,nounits"],
            text=True, timeout=3, creationflags=NO_WINDOW)
        vals = [x.strip() for x in out.strip().splitlines()[0].split(",")]

        def _f(i):
            try:
                return float(vals[i])
            except Exception:
                return None      # missing column, or "[N/A]" for unsupported fields

        return {"util": float(vals[0]), "temp": float(vals[1]),
                "vram_used": float(vals[2]), "vram_total": float(vals[3]),
                "clock": _f(4), "clock_max": _f(5),
                "mem_clock": _f(6), "mem_clock_max": _f(7)}
    except Exception:
        return None


class _GPU:
    """Pick the cheapest working GPU source once: NVML if possible, else a
    one-time nvidia-smi probe; otherwise report nothing (wallpaper simulates)."""
    def __init__(self):
        self._nvml = _NVML()
        if self._nvml.ok:
            self.mode = "nvml"
        elif _gpu_query() is not None:
            self.mode = "smi"
        else:
            self.mode = "none"

    def query(self):
        if self.mode == "nvml":
            r = self._nvml.query()
            if r is not None:
                return r
            self.mode = "smi"          # NVML degraded mid-run; fall back
        if self.mode == "smi":
            return _gpu_query()
        return None


GPU = _GPU()


# ---------------------------------------------------------------------------
# Process table on Windows: one NtQuerySystemInformation call returns every
# process's name, CPU time and working set (~5 ms for ~370 processes). psutil
# opens each process on its own and, for every protected one it cannot open,
# re-reads that whole system table as a fallback: the same scan through psutil
# measured ~850 ms of CPU a pass. GPU share per process comes from the PDH
# "GPU Engine" counters, which are what Task Manager's GPU column reads.
# Either one falls back cleanly: to psutil, or to rows without a GPU reading.
# ---------------------------------------------------------------------------
PROC_ROWS = 20      # top rows sent per sort key; the wallpaper's PROC_ROWS_MAX

# SYSTEM_PROCESS_INFORMATION, 64-bit: NextEntryOffset @0, CreateTime @32,
# UserTime @40, KernelTime @48, ImageName.Length @56, ImageName.Buffer @64,
# UniqueProcessId @80, WorkingSetSize @144
_SPI = "<I28xqqqH6xQ8xQ56xQ"


class _NtProcs:
    def __init__(self):
        self.ok = False
        self._prev = {}           # pid -> (create time, cpu time), to diff against
        self._prev_t = None
        if sys.platform != "win32" or ctypes.sizeof(ctypes.c_void_p) != 8:
            return
        try:
            import struct
            self._unpack = struct.Struct(_SPI).unpack_from
            f = ctypes.WinDLL("ntdll").NtQuerySystemInformation
            f.argtypes = [ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong,
                          ctypes.POINTER(ctypes.c_ulong)]
            f.restype = ctypes.c_long
            self._q = f
            self._buf = ctypes.create_string_buffer(1 << 20)
            # also the CPU baseline: every process reads 0% on its first sample
            self.ok = self.sample() is not None
        except Exception:
            self.ok = False

    def _read(self):
        need = ctypes.c_ulong(0)
        for _ in range(4):
            st = self._q(5, self._buf, len(self._buf), ctypes.byref(need)) & 0xFFFFFFFF
            if st == 0:
                return True
            if st != 0xC0000004:      # STATUS_INFO_LENGTH_MISMATCH: grow and retry
                return False
            self._buf = ctypes.create_string_buffer(need.value + (64 << 10))
        return False

    def sample(self):
        """[(pid, name, cpu, rss)] with cpu as a share of all cores, or None."""
        if not self._read():
            return None
        now = time.monotonic()
        dt = (now - self._prev_t) if self._prev_t else 0.0
        scale = 100.0 / (1e7 * dt * NCORES) if dt > 0 else 0.0   # 100 ns ticks -> %
        rows, seen, off = [], {}, 0
        while True:
            nxt, create, user, kernel, nlen, nptr, pid, rss = self._unpack(self._buf, off)
            if pid:                   # 0 is the idle task
                name = ctypes.wstring_at(nptr, nlen // 2) if nptr and nlen else "?"
                t = user + kernel
                prev = self._prev.get(pid)
                cpu = (t - prev[1]) * scale if prev and prev[0] == create else 0.0
                seen[pid] = (create, t)
                if name.lower() not in IDLE_NAMES:
                    rows.append((pid, name, max(cpu, 0.0), rss))
            if not nxt:
                break
            off += nxt
        self._prev, self._prev_t = seen, now
        return rows


class _PdhItem(ctypes.Structure):
    # PDH_FMT_COUNTERVALUE_ITEM_W
    _fields_ = [("szName", ctypes.c_wchar_p), ("FmtValue", _PdhValue)]


class _GpuProcs:
    """GPU share per process, the way Task Manager's GPU column computes it:
    the busiest engine that process uses. The wildcard query picks up
    processes started after it was opened, and drops ones that exit."""
    # pid_1234_luid_0x00000000_0x0000C0D3_phys_0_eng_3_engtype_3D
    _RX = re.compile(r"pid_(\d+)_luid_\w+?_phys_\d+_eng_\d+")

    def __init__(self):
        self.ok = False
        if sys.platform != "win32":
            return
        try:
            pdh = ctypes.WinDLL("pdh.dll")
            self._q = ctypes.c_void_p()
            if pdh.PdhOpenQueryW(None, 0, ctypes.byref(self._q)) != 0:
                return
            self._c = ctypes.c_void_p()
            path = r"\GPU Engine(*)\Utilization Percentage"
            if pdh.PdhAddEnglishCounterW(self._q, path, 0, ctypes.byref(self._c)) != 0:
                return
            pdh.PdhCollectQueryData(self._q)  # prime: rate counters need two samples
            self._pdh = pdh
            self.ok = True
        except Exception:
            pass

    def sample(self):
        """{pid: percent}, or None when there is no reading this time."""
        if not self.ok:
            return None
        try:
            pdh = self._pdh
            if pdh.PdhCollectQueryData(self._q) != 0:
                return None
            size, count = ctypes.c_ulong(0), ctypes.c_ulong(0)
            # 0x8200 = PDH_FMT_DOUBLE | PDH_FMT_NOCAP100; the first call sizes the buffer
            pdh.PdhGetFormattedCounterArrayW(self._c, 0x8200, ctypes.byref(size),
                                             ctypes.byref(count), None)
            if not size.value:
                return {}
            buf = ctypes.create_string_buffer(size.value)
            if pdh.PdhGetFormattedCounterArrayW(self._c, 0x8200, ctypes.byref(size),
                                                ctypes.byref(count), buf) != 0:
                return None
            items = ctypes.cast(buf, ctypes.POINTER(_PdhItem))
            engines = {}
            for i in range(count.value):
                it = items[i]
                if it.FmtValue.CStatus > 1:   # 0 valid, 1 new data
                    continue
                m = self._RX.match(it.szName or "")
                if m:
                    k = m.group(0)
                    engines[k] = (int(m.group(1)),
                                  engines.get(k, (0, 0.0))[1] + it.FmtValue.doubleValue)
            per = {}
            for pid, v in engines.values():
                per[pid] = max(per.get(pid, 0.0), min(v, 100.0))
            return per
        except Exception:
            return None


NT_PROCS = _NtProcs()
GPU_PROCS = _GpuProcs()


def _ram_mhz():
    """Installed RAM speed in MT/s (what vendors label 'MHz'). Hardware-static,
    so it is read once at startup. ConfiguredClockSpeed is the speed the module
    actually runs at (XMP/JEDEC); Speed is the rated fallback."""
    if sys.platform != "win32":
        return None
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_PhysicalMemory | ForEach-Object { "
             "if ($_.ConfiguredClockSpeed) { $_.ConfiguredClockSpeed } "
             "elseif ($_.Speed) { $_.Speed } }"],
            text=True, timeout=15, creationflags=NO_WINDOW)
        speeds = [int(x) for x in out.split() if x.strip().isdigit()]
        return max(speeds) if speeds else None
    except Exception:
        return None


RAM_MHZ = _ram_mhz()


def _collect_sysinfo():
    """Static machine identity, gathered once at startup. The wallpaper shows
    these in the neofetch block instead of the fictional defaults."""
    info = {}
    try:
        info["host"] = platform.node() or None
        info["kernel"] = platform.version() or None
        if sys.platform == "win32":
            info["os"] = "Windows " + platform.release()
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                     r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
                info["cpu"] = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
            except Exception:
                info["cpu"] = platform.processor() or None
            try:
                # Pick the *active* GPU, not just the first enumerated one: skip
                # disabled/errored adapters (ConfigManagerErrorCode != 0, e.g. a
                # disabled iGPU) and prefer the one actually driving a display.
                gpu_ps = (
                    "$c = Get-CimInstance Win32_VideoController | "
                    "Where-Object { $_.ConfigManagerErrorCode -eq 0 -and $_.Name };"
                    "$g = $c | Where-Object { $_.CurrentHorizontalResolution -gt 0 } | "
                    "Select-Object -First 1;"
                    "if (-not $g) { $g = $c | Select-Object -First 1 };"
                    "if ($g) { $g.Name }"
                )
                out = subprocess.check_output(
                    ["powershell", "-NoProfile", "-Command", gpu_ps],
                    text=True, timeout=15, creationflags=NO_WINDOW)
                info["gpu"] = out.strip() or None
            except Exception:
                info["gpu"] = None
        else:
            info["os"] = platform.system() + " " + platform.release()
            info["cpu"] = platform.processor() or platform.machine() or None
            info["gpu"] = None
        info["monitors"] = _monitors()
    except Exception:
        pass
    return info


SYSINFO = _collect_sysinfo()

# ---------------------------------------------------------------------------
# Sampler: keeps lightweight state so we can compute rates (deltas over time).
# ---------------------------------------------------------------------------
class Sampler:
    def __init__(self):
        self._lock = threading.Lock()
        self._last_t = time.time()
        self._last_cpu = psutil.cpu_times()
        self._last_disk = psutil.disk_io_counters()
        self._last_net = psutil.net_io_counters()
        self._last_perdisk = {}        # drive letter -> cumulative (read, write) bytes
        self._tick = 0
        self._users = self._count_users()
        # prime per-process CPU counters (first reading is meaningless);
        # the Windows bulk reader primed its own when it was created
        if not NT_PROCS.ok:
            for p in psutil.process_iter():
                try:
                    p.cpu_percent(None)
                except Exception:
                    pass
        # Tailnet is a separate CLI call on a slower cadence; cache it.
        self._tailnet = _tailnet()
        # The all-process scan that ranks the top rows is the heaviest part
        # of a sample, so it runs on its own slower thread — the process table
        # doesn't need 1 Hz. The live gauges built below stay at 1 Hz and never
        # wait on it. Prime it once so the very first response already has rows.
        self._procs = self._top_procs(psutil.virtual_memory().total)
        self._cache = self._build()
        # Sample on our own cadence in the background; HTTP requests always serve
        # the cached snapshot instantly instead of paying for a scan.
        threading.Thread(target=self._sample_loop, daemon=True).start()
        threading.Thread(target=self._procs_loop, daemon=True).start()
        threading.Thread(target=self._tailnet_loop, daemon=True).start()

    def _sample_loop(self):
        while True:
            time.sleep(1.0)
            snap = self._build()
            with self._lock:
                self._cache = snap

    def _procs_loop(self):
        # Process table: refresh every 2 s. This is the one expensive scan
        # (one OS handle per process); keeping it off the 1 Hz path is what holds
        # steady-state CPU down without touching live-gauge freshness.
        while True:
            time.sleep(2.0)
            rows = self._top_procs(psutil.virtual_memory().total)
            with self._lock:
                self._procs = rows

    def _tailnet_loop(self):
        while True:
            time.sleep(5.0)
            tn = _tailnet()
            with self._lock:
                self._tailnet = tn

    def _cpu_percent(self):
        # psutil.cpu_percent() keys its baseline per-thread; under a
        # thread-per-request server every call is a "first call" and
        # returns 0.0 forever. Compute the busy/total delta ourselves.
        cur = psutil.cpu_times()
        busy = (sum(cur) - cur.idle) - (sum(self._last_cpu) - self._last_cpu.idle)
        total = sum(cur) - sum(self._last_cpu)
        self._last_cpu = cur
        if total <= 0:
            return 0.0
        return min(max(100.0 * busy / total, 0.0), 100.0)

    def _cpu_temp(self):
        # Not available on most Windows / some macOS setups.
        if not _HAS_TEMP:
            return None
        try:
            temps = psutil.sensors_temperatures()
        except Exception:
            return None
        if not temps:
            return None
        # Prefer common CPU sensors, else first available reading.
        for key in ("coretemp", "k10temp", "cpu_thermal", "acpitz", "zenpower"):
            if key in temps and temps[key]:
                return round(temps[key][0].current, 1)
        for arr in temps.values():
            if arr:
                return round(arr[0].current, 1)
        return None

    def _count_users(self):
        # Distinct logged-in users (like the count in `uptime`).
        try:
            return len({u.name for u in psutil.users()}) or 1
        except Exception:
            return None

    def _drives_posix(self, dt):
        """Linux/macOS drives: real mounts via psutil (fixed filesystems only),
        with live per-device throughput where the kernel exposes it. Matters for
        the remote-server use: a Linux companion should show its real disks."""
        SKIP_FS = {"tmpfs", "devtmpfs", "squashfs", "overlay", "ramfs", "zram",
                   "proc", "sysfs", "efivarfs", "autofs", "fuse.gvfsd-fuse"}
        try:
            perdisk = psutil.disk_io_counters(perdisk=True) or {}
        except Exception:
            perdisk = {}
        out, seen_dev = [], set()
        try:
            parts = psutil.disk_partitions(all=False)
        except Exception:
            return []
        for part in parts:
            if part.fstype.lower() in SKIP_FS or not part.device.startswith("/dev/"):
                continue
            if part.device in seen_dev:        # bind mounts / btrfs subvolumes
                continue
            seen_dev.add(part.device)
            try:
                u = psutil.disk_usage(part.mountpoint)
            except Exception:
                continue
            dev = os.path.basename(part.device)
            c = perdisk.get(dev)
            rb = c.read_bytes if c else 0
            wb = c.write_bytes if c else 0
            prev = self._last_perdisk.get(dev)
            self._last_perdisk[dev] = (rb, wb)
            read_mbs = write_mbs = 0.0
            if prev and dt > 0 and (rb or wb):
                read_mbs = max(rb - prev[0], 0) / dt / (1024 * 1024)
                write_mbs = max(wb - prev[1], 0) / dt / (1024 * 1024)
            mp = part.mountpoint
            out.append({
                "id": "/" if mp == "/" else (os.path.basename(mp)[:6] or mp[:6]),
                "label": dev,
                "total_gb": round(u.total / (1024 ** 3), 1),
                "used_pct": round(u.used / u.total * 100) if u.total else 0,
                "read_mbs": round(read_mbs, 1),
                "write_mbs": round(write_mbs, 1),
            })
        out.sort(key=lambda d: (d["id"] != "/", d["id"]))
        return out[:6]                          # HUD panel space is finite

    def _drives_native(self, dt):
        """Every fixed drive with usage + live read/write throughput, computed
        natively via psutil (no subprocess). Label and physical-disk mapping
        come from the cached startup map; an unmapped drive simply reports 0 R/W
        but still shows correct usage."""
        if sys.platform != "win32":
            return self._drives_posix(dt)
        try:
            perdisk = psutil.disk_io_counters(perdisk=True) or {}
        except Exception:
            perdisk = {}
        # psutil sees hot-plugged fixed drives live; the startup map supplies
        # label + physical mapping. Union the two so neither misses a drive.
        seen, parts = set(), []
        try:
            for part in psutil.disk_partitions(all=False):
                letter = part.device.rstrip("\\/")
                if "fixed" in part.opts or letter in DRIVE_STATIC:
                    parts.append((letter, part.mountpoint))
                    seen.add(letter)
        except Exception:
            pass
        for letter in DRIVE_STATIC:
            if letter not in seen:
                parts.append((letter, letter + "\\"))

        out = []
        for letter, mount in parts:
            try:
                u = psutil.disk_usage(mount)
            except Exception:
                continue
            st = DRIVE_STATIC.get(letter, {})
            rb = wb = 0
            for phys in st.get("phys", []):
                c = perdisk.get(phys)
                if c:
                    rb += c.read_bytes
                    wb += c.write_bytes
            prev = self._last_perdisk.get(letter)
            self._last_perdisk[letter] = (rb, wb)
            read_mbs = write_mbs = 0.0
            if prev and dt > 0 and (rb or wb):
                read_mbs = max(rb - prev[0], 0) / dt / (1024 * 1024)
                write_mbs = max(wb - prev[1], 0) / dt / (1024 * 1024)
            out.append({
                "id": letter,
                "label": st.get("label", ""),
                "total_gb": round(u.total / (1024 ** 3), 1),
                "used_pct": round((u.total - u.free) / u.total * 100) if u.total else 0,
                "read_mbs": round(read_mbs, 1),
                "write_mbs": round(write_mbs, 1),
            })
        out.sort(key=lambda d: d["id"])
        return out

    def _top_procs(self, total_bytes, n=PROC_ROWS):
        # The wallpaper picks the sort and the length, so send the top n rows by
        # CPU, by memory and by GPU, each with all three readings. Ties fall
        # through to the next column, the same order the wallpaper sorts in.
        rows = NT_PROCS.sample() if NT_PROCS.ok else None
        if rows is None:
            rows = self._psutil_procs()
        gpu = GPU_PROCS.sample()
        out = []
        for pid, name, cpu, rss in rows:
            r = {"pid": pid, "name": name[:12], "cpu": cpu,
                 "mem": rss / total_bytes * 100 if total_bytes else 0.0}
            if gpu is not None:
                r["gpu"] = gpu.get(pid, 0.0)
            out.append(r)
        orders = [("cpu", "mem", "gpu"), ("mem", "cpu", "gpu")]
        if gpu is not None:
            orders.append(("gpu", "cpu", "mem"))
        keep = set()
        for keys in orders:
            ranked = sorted(range(len(out)), reverse=True,
                            key=lambda i: tuple(out[i].get(k, 0.0) for k in keys))
            keep.update(ranked[:n])
        # CPU order: a wallpaper from before the sort option shows the first five
        top = sorted((out[i] for i in keep), key=lambda r: r["cpu"], reverse=True)
        for r in top:
            for k in ("cpu", "mem", "gpu"):
                if k in r:
                    r[k] = round(r[k], 1)
        return top

    def _psutil_procs(self):
        # Linux and macOS, or Windows when the bulk call failed: one memory read
        # per process, which is cheap from /proc and slow on Windows.
        rows = []
        for p in psutil.process_iter(["pid", "name"]):
            try:
                pid = p.info["pid"]
                name = p.info.get("name") or "?"
                if pid == 0 or name.lower() in IDLE_NAMES:
                    continue
                with p.oneshot():
                    # per-process cpu_percent is per-core (can exceed 100);
                    # normalize to share of total CPU, like Task Manager.
                    rows.append((pid, name, p.cpu_percent(None) / NCORES,
                                 p.memory_info().rss))
            except Exception:
                continue
        return rows

    def _build(self):
        now = time.time()
        dt = max(now - self._last_t, 1e-3)

        cpu = self._cpu_percent()
        cpu_mhz, cpu_mhz_max = CPU_CLOCK.query()
        vm = psutil.virtual_memory()
        sm = psutil.swap_memory()

        disk = psutil.disk_io_counters()
        d_bytes = (disk.read_bytes + disk.write_bytes) - \
                  (self._last_disk.read_bytes + self._last_disk.write_bytes)
        disk_mbs = max(d_bytes, 0) / dt / (1024 * 1024)

        net = psutil.net_io_counters()
        down_kbs = max(net.bytes_recv - self._last_net.bytes_recv, 0) / dt / 1024
        up_kbs = max(net.bytes_sent - self._last_net.bytes_sent, 0) / dt / 1024

        drives = self._drives_native(dt)

        self._last_t = now
        self._last_disk = disk
        self._last_net = net

        # Logged-in user count changes rarely; refresh every ~30 s, not every tick.
        self._tick += 1
        if self._tick % 30 == 0:
            self._users = self._count_users()

        return {
            "cpu": round(cpu, 1),
            "cpu_mhz": cpu_mhz,
            "cpu_mhz_max": cpu_mhz_max,
            "ram": round(vm.percent, 1),
            "ram_mhz": RAM_MHZ,
            "ram_total_mb": round(vm.total / (1024 * 1024)),
            "cpu_count": NCORES,
            "swap": round(sm.percent, 1),
            "cpu_temp": self._cpu_temp(),
            "disk_mbs": round(disk_mbs, 1),
            "net_down_kbs": round(down_kbs, 1),
            "net_up_kbs": round(up_kbs, 1),
            "uptime_sec": int(now - BOOT_TIME),
            "nproc": len(psutil.pids()),
            "nusers": self._users,
            "sys": SYSINFO,
            "gpu": GPU.query(),
            "drives": drives,
            "tailnet": self._tailnet,
            "procs": self._procs,
            "ts": now,
        }

    def get(self):
        with self._lock:
            return self._cache


SAMPLER = Sampler()

# ---------------------------------------------------------------------------
# Wallpaper Engine audio-capture watchdog  (opt-in, Windows only)
#
# WE captures desktop audio by loopback from whatever endpoint is the Windows
# default. When that default changes under it (headset connects, BT dongle
# sleeps, you flip output in the volume flyout) its capture can keep reading the
# old endpoint and hand the wallpaper all-zero frames indefinitely. Nothing logs
# an error; the visualizer just goes dead. Restarting WE reattaches capture.
#
# Acting on every device switch would blink the wallpaper constantly, so we
# remediate only on evidence of the real fault: audio IS playing (we read the
# endpoint's own peak meter) AND the wallpaper reports it is receiving silence
# (aud=0 on the metrics request it already makes every second).
#
# Off unless --we-audio-watchdog is passed. A stats app that restarts another
# program is intrusive, and a misfire costs a visible wallpaper reload.
#
# Even a correct restart is a visible reload, and headset and VR switching can
# kill capture several times a day. So a confirmed fault is only queued, and the
# restart waits until nobody has touched the keyboard or mouse for a while.
# ---------------------------------------------------------------------------
WE_DIR_DEFAULT = r"C:\Program Files (x86)\Steam\steamapps\common\wallpaper_engine"

# what the wallpaper last told us about its audio feed
_AUDIO_LOCK = threading.Lock()
_AUDIO_REPORT = {"state": None, "sum": 0.0, "ts": 0.0, "screens": None, "viewport": None}


def _note_audio_report(path):
    """Record ?aud=/&audsum= from a /metrics request. Absent on old wallpapers
    and on remote setups, in which case the watchdog simply stays idle.

    The same request carries &scr= and &vp=, the wallpaper's screen count and
    viewport. On a spanned setup those are the only way to see what layout the
    wallpaper actually resolved without screenshotting somebody's desktop or
    opening a CEF debug port, and both of those are miserable to do live."""
    if "?" not in path:
        return
    try:
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
    except Exception:
        return
    state = (q.get("aud") or [None])[0]
    if state not in ("0", "1", "x"):
        return
    try:
        total = float((q.get("audsum") or ["0"])[0])
    except ValueError:
        total = 0.0
    try:
        screens = int((q.get("scr") or ["0"])[0]) or None
    except ValueError:
        screens = None
    viewport = (q.get("vp") or [None])[0]
    if viewport and not re.match(r"^\d{2,5}x\d{2,5}$", viewport):
        viewport = None
    with _AUDIO_LOCK:
        _AUDIO_REPORT["state"] = state
        _AUDIO_REPORT["sum"] = total
        _AUDIO_REPORT["ts"] = time.time()
        _AUDIO_REPORT["screens"] = screens
        _AUDIO_REPORT["viewport"] = viewport


_CLSCTX_ALL = 23
_CLSID_MMDEVICE_ENUM = "{BCDE0395-E52F-467C-8E3D-C4579291692E}"
_IID_IMMDEVICE_ENUM = "{A95664D2-9614-4F35-A746-DE8DB63617E6}"
_IID_IAUDIO_METER = "{C02216F6-8C67-4B5B-9D00-D008E73E0064}"


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


_GUID_CACHE = {}


def _guid(text):
    """Parsed once and cached: CLSIDFromString on every poll would be wasteful,
    and holding the objects keeps them alive for byref() calls."""
    g = _GUID_CACHE.get(text)
    if g is None:
        g = _GUID()
        if ctypes.windll.ole32.CLSIDFromString(ctypes.c_wchar_p(text), ctypes.byref(g)) != 0:
            raise OSError("bad GUID: " + text)
        _GUID_CACHE[text] = g
    return g


def _vcall(ptr, index, *argtypes):
    """Call COM method #index through the vtable, no comtypes/pycaw needed.
    That matters: the no-Python edition is a PyInstaller bundle, and this keeps
    its dependency list (psutil only) unchanged."""
    vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
    proto = ctypes.WINFUNCTYPE(ctypes.c_int32, ctypes.c_void_p, *argtypes)
    return proto(vtbl[index])


def _com_release(ptr):
    if ptr:
        _vcall(ptr, 2)(ptr)


_COM_TLS = threading.local()


def _ensure_com():
    """CoCreateInstance fails with CO_E_NOTINITIALIZED unless the *calling*
    thread has initialized COM, so do it lazily per thread (once: repeat calls
    would just inflate the init count)."""
    if getattr(_COM_TLS, "ready", False):
        return
    ctypes.windll.ole32.CoInitialize(None)
    _COM_TLS.ready = True


def _default_output_level():
    """(device_id, peak 0..1) for the default multimedia output endpoint.
    Returns (None, 0.0) if anything goes wrong, which keeps the watchdog idle
    rather than guessing."""
    _ensure_com()
    ole32 = ctypes.windll.ole32
    enum = ctypes.c_void_p()
    hr = ole32.CoCreateInstance(ctypes.byref(_guid(_CLSID_MMDEVICE_ENUM)), None,
                                _CLSCTX_ALL,
                                ctypes.byref(_guid(_IID_IMMDEVICE_ENUM)),
                                ctypes.byref(enum))
    if hr != 0 or not enum:
        return (None, 0.0)
    dev = ctypes.c_void_p()
    meter = ctypes.c_void_p()
    try:
        # IMMDeviceEnumerator::GetDefaultAudioEndpoint(eRender=0, eMultimedia=1)
        hr = _vcall(enum, 4, ctypes.c_int32, ctypes.c_int32,
                    ctypes.POINTER(ctypes.c_void_p))(enum, 0, 1, ctypes.byref(dev))
        if hr != 0 or not dev:
            return (None, 0.0)
        dev_id = None
        pid = ctypes.c_wchar_p()
        if _vcall(dev, 5, ctypes.POINTER(ctypes.c_wchar_p))(dev, ctypes.byref(pid)) == 0:
            dev_id = pid.value
            ole32.CoTaskMemFree(pid)
        # IMMDevice::Activate(IAudioMeterInformation)
        hr = _vcall(dev, 3, ctypes.POINTER(_GUID), ctypes.c_uint32, ctypes.c_void_p,
                    ctypes.POINTER(ctypes.c_void_p))(
                        dev, ctypes.byref(_guid(_IID_IAUDIO_METER)),
                        _CLSCTX_ALL, None, ctypes.byref(meter))
        if hr != 0 or not meter:
            return (dev_id, 0.0)
        peak = ctypes.c_float()
        if _vcall(meter, 3, ctypes.POINTER(ctypes.c_float))(meter, ctypes.byref(peak)) != 0:
            return (dev_id, 0.0)
        return (dev_id, float(peak.value))
    finally:
        _com_release(meter)
        _com_release(dev)
        _com_release(enum)


_ENUM_PROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)


def _stacked_view_count():
    """Largest number of CEF views inside one of WE's desktop wallpaper windows.

    2 or more is WE's duplicate-view bug: two Chrome_WidgetWin_1 views stack in
    the same WPEDesktopCEFWindow and the one on top receives no user properties
    and no audio callbacks, so the wallpaper renders defaults and ignores audio
    even when capture is perfectly healthy. Restarting WE can land in this state,
    so we check for it after remediating."""
    user32 = ctypes.windll.user32
    buf = ctypes.create_unicode_buffer(256)

    def class_of(hwnd):
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value

    desktop_windows = []

    def find_desktop(hwnd, _lparam):
        if class_of(hwnd) == "WPEDesktopCEFWindow":
            desktop_windows.append(hwnd)
        return True

    find_cb = _ENUM_PROC(find_desktop)

    def descend(parent, depth=0):
        # WE's wallpaper window hangs off Progman/WorkerW, so a plain EnumWindows
        # never sees it; walk down a few levels instead.
        if depth > 4:
            return
        kids = []

        def collect(hwnd, _lparam):
            kids.append(hwnd)
            return True

        cb = _ENUM_PROC(collect)
        user32.EnumChildWindows(parent, cb, None)
        for k in kids:
            find_desktop(k, None)
            descend(k, depth + 1)

    tops = []

    def collect_top(hwnd, _lparam):
        if class_of(hwnd) in ("Progman", "WorkerW"):
            tops.append(hwnd)
        return True

    top_cb = _ENUM_PROC(collect_top)
    user32.EnumWindows(top_cb, None)
    for t in tops:
        find_desktop(t, None)
        descend(t)

    best = 0
    for dw in set(desktop_windows):
        views = []

        def count_views(hwnd, _lparam):
            if class_of(hwnd) == "Chrome_WidgetWin_1":
                views.append(hwnd)
            return True

        cb = _ENUM_PROC(count_views)
        user32.EnumChildWindows(dw, cb, None)
        best = max(best, len(set(views)))
    del find_cb, top_cb
    return best


class _LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint32), ("dwTime", ctypes.c_uint32)]


def _input_idle_seconds():
    """Seconds since the last keyboard or mouse input in this session. 0.0 if it
    cannot be read, which keeps a queued restart waiting rather than firing."""
    info = _LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(info)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    # Both are 32-bit tick counts, so masking keeps this right across the
    # 49.7-day wrap.
    return ((ctypes.windll.kernel32.GetTickCount() - info.dwTime) & 0xFFFFFFFF) / 1000.0


def _default_watchdog_log():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "CyberOS-HUD", "we-watchdog.log")


class WeAudioWatchdog(threading.Thread):
    PEAK_MIN = 0.01          # output level that counts as "audio is playing"
    STARVE_SECONDS = 8.0     # mismatch must hold this long before we act
    COOLDOWN = 180.0         # never remediate more often than this
    REPORT_MAX_AGE = 6.0     # older wallpaper reports are stale, ignore them
    POLL = 2.0
    # Restarting WE is disruptive, so a remedy that plainly is not working must
    # not keep repeating. If starvation comes straight back after a restart the
    # cooldown backs off, and after this many failed attempts we stop and say so
    # rather than bouncing Wallpaper Engine every few minutes all day.
    MAX_FAILED_FIXES = 3
    BACKOFF = 4.0            # cooldown multiplier per attempt that did not stick
    RECOVERED_AFTER = 900.0  # quiet for this long = the last fix worked
    IDLE_BEFORE_FIX = 300.0  # no keyboard/mouse input for this long = nobody watching

    def __init__(self, we_dir=WE_DIR_DEFAULT, wallpaper_path="", verbose=False,
                 log_path=None):
        super().__init__(daemon=True)
        self.we_dir = we_dir
        self.wallpaper_path = wallpaper_path
        self.verbose = verbose
        self.log_path = log_path or _default_watchdog_log()
        self._starved_since = None
        self._last_fix = 0.0
        self._last_device = None
        self._failed_fixes = 0
        self._gave_up = False
        self._pending = False

    def _log(self, msg):
        print("[we-watchdog] " + msg)
        # This auto-starts at login under pythonw.exe, where stdout is the null
        # device, so the file is the only place these lines survive. Without it
        # there is no way to tell whether the watchdog ever fired.
        try:
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            with open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write("%s  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
        except Exception:
            pass

    @staticmethod
    def _we_running():
        try:
            out = subprocess.check_output(
                ["tasklist", "/FI", "IMAGENAME eq wallpaper64.exe", "/NH"],
                text=True, timeout=10, creationflags=NO_WINDOW)
            return "wallpaper64.exe" in out
        except Exception:
            return False

    def _wait_gone(self, seconds):
        deadline = time.time() + seconds
        while time.time() < deadline:
            if not self._we_running():
                return True
            time.sleep(0.5)
        return not self._we_running()

    def _clear_safe_start(self):
        """Wallpaper Engine records that it did not exit cleanly and greets the
        next launch with the "Safe Start" dialog, leaving the desktop bare until
        someone clicks OK. After a forced kill that flag is ours to clean up.
        Only safe with WE closed, which is exactly where this is called from."""
        cfg = os.path.join(self.we_dir, "config.json")
        try:
            with open(cfg, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception as exc:
            self._log("could not read config.json to clear Safe Start: %s" % exc)
            return

        hits = [0]

        def walk(node):
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == "safemode" and value is True:
                        node[key] = False
                        hits[0] += 1
                    else:
                        walk(value)
            elif isinstance(node, list):
                for value in node:
                    walk(value)

        walk(data)
        if not hits[0]:
            return
        try:
            with open(cfg, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=1)
            self._log("cleared the Safe Start flag WE was left holding")
        except Exception as exc:
            self._log("could not write config.json: %s" % exc)

    def _restart_we(self):
        exe = os.path.join(self.we_dir, "wallpaper64.exe")
        if not os.path.isfile(exe):
            self._log("wallpaper64.exe not found under " + self.we_dir)
            return False
        # Ask it to close before reaching for the hammer. A forced kill leaves
        # Wallpaper Engine convinced it crashed, so every remediation used to
        # cost the user a "Safe Start" dialog and a bare desktop until they
        # clicked through it.
        subprocess.run(["taskkill", "/IM", "wallpaper64.exe"],
                       capture_output=True, creationflags=NO_WINDOW)
        if self._wait_gone(12):
            self._log("closed WE cleanly")
        else:
            self._log("WE would not close, forcing it")
            subprocess.run(["taskkill", "/F", "/IM", "wallpaper64.exe"],
                           capture_output=True, creationflags=NO_WINDOW)
            self._wait_gone(6)
            self._clear_safe_start()
        time.sleep(2)
        subprocess.Popen([exe], creationflags=NO_WINDOW)
        time.sleep(14)
        return True

    def _repair_stacked_view(self):
        """Last resort. Letting WE auto-restore preserves the user's monitor
        layout (clone mirrors and all), which the control CLI cannot express, so
        we only force a single-view reload when the duplicate view really is
        there. This does collapse the wallpaper to monitor 0."""
        if not self.wallpaper_path:
            self._log("stacked view present but --we-wallpaper not set, leaving it")
            return
        cli = os.path.join(self.we_dir, "wallpaper32.exe")
        if not os.path.isfile(cli):
            return
        subprocess.run([cli, "-control", "closeWallpaper", "-monitor", "0"],
                       capture_output=True, creationflags=NO_WINDOW)
        time.sleep(3)
        subprocess.run([cli, "-control", "openWallpaper", "-file", self.wallpaper_path,
                        "-monitor", "0"], capture_output=True, creationflags=NO_WINDOW)
        time.sleep(6)
        self._log("reapplied wallpaper on monitor 0 to clear the stacked view")

    def _remediate(self):
        self._log("remediating: PC is idle, restarting WE to reattach audio capture")
        # Stamp the cooldown up front: if the restart fails (WE not installed
        # where we think, permissions, whatever) we must not retry every poll.
        self._last_fix = time.time()
        self._starved_since = None
        if not self._restart_we():
            return
        try:
            views = _stacked_view_count()
        except Exception as exc:
            views = 0
            self._log("view check failed: %s" % exc)
        if views > 1:
            self._log("WE came back with %d stacked views" % views)
            self._repair_stacked_view()
        self._last_fix = time.time()
        self._starved_since = None

    def run(self):
        self._log("started (peak>%.2f + wallpaper reporting silence for %.0fs)"
                  % (self.PEAK_MIN, self.STARVE_SECONDS))
        while True:
            time.sleep(self.POLL)
            try:
                device, peak = _default_output_level()
                if device and device != self._last_device:
                    if self._last_device is not None and self.verbose:
                        self._log("default output changed")
                    self._last_device = device

                with _AUDIO_LOCK:
                    state = _AUDIO_REPORT["state"]
                    age = time.time() - _AUDIO_REPORT["ts"]

                # No fresh report means no wallpaper is talking to us (or it is a
                # remote setup, or an older build): nothing to diagnose.
                fresh = state is not None and age < self.REPORT_MAX_AGE

                if self._pending:
                    # WE's own "reload audio" setting sometimes reattaches
                    # capture by itself; live samples mean the restart is moot.
                    if fresh and state == "1":
                        self._pending = False
                        self._log("audio capture came back on its own, restart canceled")
                    elif (_input_idle_seconds() >= self.IDLE_BEFORE_FIX
                          and not _fullscreen_app()):
                        self._pending = False
                        if self._last_fix:
                            self._failed_fixes += 1
                        if self._failed_fixes > self.MAX_FAILED_FIXES:
                            self._gave_up = True
                            self._log("restarting WE %d times did not restore audio capture; "
                                      "giving up until it recovers on its own"
                                      % self.MAX_FAILED_FIXES)
                        else:
                            self._remediate()
                    continue

                starved = fresh and state == "0" and peak > self.PEAK_MIN
                # Never restart WE under a fullscreen game: a deaf visualizer
                # nobody can see beats a desktop flash in the middle of a match.
                # Wallpapers from v2.11 already report "x" in game mode; this
                # covers older ones.
                if starved and _fullscreen_app():
                    starved = False

                now = time.time()
                if not starved:
                    self._starved_since = None
                    # A long quiet spell means the last restart actually stuck,
                    # so forgive the earlier failures.
                    if (self._failed_fixes and self._last_fix
                            and now - self._last_fix >= self.RECOVERED_AFTER):
                        self._failed_fixes = 0
                        self._gave_up = False
                    continue
                if self._gave_up:
                    continue
                if self._starved_since is None:
                    self._starved_since = now
                    if self.verbose:
                        self._log("starvation suspected (peak %.3f)" % peak)
                # Each restart that fails to stick pushes the next attempt further
                # out, so a remedy that is not working costs the user less and less.
                cooldown = self.COOLDOWN * (self.BACKOFF ** self._failed_fixes)
                if (now - self._starved_since >= self.STARVE_SECONDS
                        and now - self._last_fix >= cooldown):
                    self._pending = True
                    self._starved_since = None
                    self._log("audio is playing but the wallpaper reports silence; "
                              "restarting WE after %.0fs without input"
                              % self.IDLE_BEFORE_FIX)
            except Exception as exc:
                self._log("error: %s" % exc)


# ---------------------------------------------------------------------------
# Second copy of the wallpaper's dragged panel layout.
# Wallpaper Engine keeps the wallpaper's localStorage in a LevelDB log, and a
# forced kill of WE (the watchdog's only way to restart it) can tear the record
# being written. LevelDB then throws away the rest of that 32 KB block at every
# start, so every later save looks fine until the next restart and is gone
# after it: the panels jump back to an old arrangement. Seen on 2026-10-22,
# with every move since 09-29 lost that way. So the wallpaper also saves the
# layout here, stamped with the time it was made, and at start it takes
# whichever copy is newer. Only this PC can write it, and an older copy never
# replaces a newer one, so two wallpaper instances cannot undo each other.
# ---------------------------------------------------------------------------
_LAYOUT_LOCK = threading.Lock()
LAYOUT_MAX_BYTES = 64 * 1024


def _layout_path():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "CyberOS-HUD", "layout.json")


def _read_layout():
    try:
        with open(_layout_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _store_layout(raw):
    """Validate and save a layout the wallpaper posted. Returns an HTTP status.
    Shape checks only; the wallpaper validates every placement when it loads."""
    try:
        data = json.loads(raw)
    except ValueError:
        return 400
    if (not isinstance(data, dict)
            or not isinstance(data.get("ov", {}), dict)
            or not isinstance(data.get("ord", {}), dict)
            or not isinstance(data.get("t"), (int, float)) or isinstance(data.get("t"), bool)):
        return 400
    path = _layout_path()
    with _LAYOUT_LOCK:
        if _read_layout().get("t", 0) > data["t"]:
            return 409
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    return 204


# ---------------------------------------------------------------------------
# HTTP handler with permissive CORS so the wallpaper's browser can fetch it.
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Cache-Control", "no-store")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/metrics"):
            # the wallpaper piggybacks its audio-feed state on this request
            _note_audio_report(self.path)
            body = SAMPLER.get()
            fullscreen = _fullscreen_app()
            if fullscreen is not None:
                body = dict(body, fullscreen=fullscreen)
            payload = json.dumps(body).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        elif self.path.startswith("/audio"):
            # Diagnostic: what the wallpaper last reported about its audio feed,
            # next to the real output level. Lets you tell "WE is feeding the
            # wallpaper silence" from "nothing is playing" with one curl.
            with _AUDIO_LOCK:
                state = _AUDIO_REPORT["state"]
                total = _AUDIO_REPORT["sum"]
                ts = _AUDIO_REPORT["ts"]
                screens = _AUDIO_REPORT["screens"]
                viewport = _AUDIO_REPORT["viewport"]
            device, peak = (None, 0.0)
            if sys.platform == "win32":
                try:
                    device, peak = _default_output_level()
                except Exception:
                    pass
            body = {
                "wallpaper_audio": state,            # "1" live, "0" starved, "x" off, null none
                "wallpaper_frame_sum": round(total, 6),
                "report_age_s": round(time.time() - ts, 2) if ts else None,
                "output_peak": round(peak, 5),
                "output_device": device,
                # layout the wallpaper resolved: >1 screens means it is spanning
                "wallpaper_screens": screens,
                "wallpaper_viewport": viewport,
            }
            payload = json.dumps(body).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        elif self.path.startswith("/layout"):
            # Only this PC's wallpaper keeps a layout here, so a bind to a LAN
            # or tailnet address must not publish it either.
            if not self._loopback():
                self.send_response(403)
                self._cors()
                self.end_headers()
                return
            payload = json.dumps(_read_layout()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self._cors()
            self.end_headers()
            self.wfile.write(b"CyberOS HUD metrics companion. GET /metrics or /audio")

    def _loopback(self):
        return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def do_POST(self):
        # The wallpaper posts as text/plain, a "simple" request, so the browser
        # sends it without an OPTIONS preflight.
        status = 404
        if self.path.startswith("/layout"):
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = -1
            if not self._loopback():
                status = 403
            elif not 0 < length <= LAYOUT_MAX_BYTES:
                status = 413 if length > LAYOUT_MAX_BYTES else 400
            else:
                try:
                    status = _store_layout(self.rfile.read(length).decode("utf-8"))
                except Exception:
                    status = 500
        self.send_response(status)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *args):
        pass  # stay quiet


class Server(ThreadingHTTPServer):
    # Default SO_REUSEADDR lets a second copy silently double-bind the port
    # on Windows while the first keeps serving; make duplicates fail loudly.
    allow_reuse_address = False


def main():
    import argparse
    ap = argparse.ArgumentParser(
        description="CyberOS HUD metrics companion (read-only stats server)")
    ap.add_argument("--host", default=HOST,
                    help="interface to bind (default 127.0.0.1 = this PC only). "
                         "To feed the wallpaper on ANOTHER machine, bind a LAN/"
                         "tailnet IP or 0.0.0.0 and set that host in the "
                         "wallpaper's 'Remote metrics host' property.")
    ap.add_argument("--port", type=int, default=PORT,
                    help=f"TCP port to serve on (default {PORT})")
    ap.add_argument("--we-audio-watchdog", action="store_true",
                    help="Windows only. Watch for Wallpaper Engine's audio capture "
                         "going deaf after the default output device changes, and "
                         "restart WE when the wallpaper reports it is receiving "
                         "silence while audio is actually playing. Off by default.")
    ap.add_argument("--we-dir", default=WE_DIR_DEFAULT,
                    help="Wallpaper Engine install folder (for --we-audio-watchdog)")
    ap.add_argument("--we-wallpaper", default="",
                    help="path to your wallpaper's index.html/project.json. Only used "
                         "as a fallback when WE restarts into its duplicate-view bug; "
                         "reapplying collapses the wallpaper to monitor 0.")
    args = ap.parse_args()
    try:
        server = Server((args.host, args.port), Handler)
    except OSError:
        raise SystemExit(
            f"\n[!] Can't bind {args.host}:{args.port} — the companion is probably "
            "already running (or the address isn't local).\n"
            "    Close the other window first.\n"
        )
    print("=" * 52)
    print("  CyberOS HUD — Real Metrics Companion")
    print(f"  Serving live stats at  http://{args.host}:{args.port}/metrics")
    if args.host != "127.0.0.1":
        print("  NOTE: bound to a non-loopback address, so these read-only")
        print("  stats are visible to other machines that can reach this one.")
    print("  The wallpaper will pick this up automatically.")
    if args.we_audio_watchdog:
        if sys.platform == "win32":
            WeAudioWatchdog(we_dir=args.we_dir,
                            wallpaper_path=args.we_wallpaper,
                            verbose=True).start()
            print("  WE audio-capture watchdog: ON")
        else:
            print("  WE audio-capture watchdog: ignored (Windows only)")
    print("  Leave this running (you can minimize it). Ctrl+C to stop.")
    print("=" * 52)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping companion. Wallpaper will fall back to simulation.")
        server.shutdown()


if __name__ == "__main__":
    main()
